My name is:<?php echo (int)$_POST['firstname']; ?>. 
Surname is:<?php echo (int)$_POST['surname']; ?>. 
Email is:<?php echo (int)$_POST['email']; ?>. 
Postcode:<?php echo htmlspecialchars($_POST['postcode']); ?>.