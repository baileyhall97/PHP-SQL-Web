Hi your username is: <?php echo htmlspecialchars($_POST['username']); ?>.
And email address is:<?php echo htmlspecialchars($_POST['email']); ?>. 
