First name: <?php echo htmlspecialchars($_POST['firstname']); ?>.
Surname: <?php echo htmlspecialchars($_POST['surname']) ?>.
Email:   <?php echo htmlspecialchars($_POST['email']); ?>.
Food rating: <?php echo htmlspecialchars($_POST['foodrating']); ?>.
Average weekly purchase   $:<?php echo htmlspecialchars($_POST['Spending']); ?>.
Comments: <?php echo htmlspecialchars($_POST['comments']); ?>.