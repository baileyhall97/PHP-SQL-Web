Hi <?php echo htmlspecialchars($_POST['name']); ?>.
Car registration number is <?php echo htmlspecialchars($_POST['registration']); ?> license plate. 
