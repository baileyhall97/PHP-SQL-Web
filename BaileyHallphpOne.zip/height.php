Height is: <?php echo htmlspecialchars($_POST['height']); ?>.
My name is: <?php echo htmlspecialchars($_POST['name']); ?>.
